

ABOUT
——

Pissjar Sans – A typeface made of piss created for Pissjar (pissjar.bandcamp.com) by Anton Bolin.


LICENSE
——

Use it for whatever you like, as long as it isn’t some nazi bullshit.


PROHBITIONS
——

You do not have the rights to redistribute, resell, lease, license, sublicense or sell Pissjar Sans without permission. If you wish to promote Pissjar on your site, you must link back to the resource page where users can find the download and not directly to the download file.


CONTACT
——
Anton Bolin
anton.bolin@gmail.com
antonbolin.se
behance.com/antonbolin






